require("dotenv").config();
const express = require("express");
const path = require("path");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const pool = require("./database/pool");
const studentsRoutes = require("./routes/students");
const lecturersRouter = require("./routes/lecturers");

// Your existing routes
const statsRoutes = require("./routes/stats");
const calendarRoutes = require("./routes/calendar");
const eventRoutes = require("./routes/events");


// NEW exam system routes
const examsRoutes = require("./routes/exams");
const questionsRoutes = require("./routes/questions");
const submissionsRoutes = require("./routes/submissions");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Existing
app.use("/api/stats", statsRoutes);
app.use("/api/calendar", calendarRoutes);
app.use("/events", eventRoutes);

// NEW
app.use("/api/exams", examsRoutes);
app.use("/api/questions", questionsRoutes);
app.use("/api/submissions", submissionsRoutes);
app.use("/api/students", studentsRoutes);
app.use("/api/lecturers", lecturersRouter);

app.use('/Css', express.static(path.join(__dirname, '../client/Frontend/Css')));
app.use(express.static(path.join(__dirname, "../client/Frontend/HTML")));
app.use('/images', express.static(path.join(__dirname, '../client/Frontend/images')));


/* ======================
   ✅ REGISTER (STUDENT ONLY)
   ====================== */
app.post("/api/register", async (req, res) => {
  try {
    const { fullname, email, password } = req.body;

    if (!fullname || !email || !password) {
      return res
        .status(400)
        .json({ error: "Fullname, email, and password are required" });
    }

    // Check if email already exists in any role
    const existing =
      (await pool.query("SELECT 1 FROM admins WHERE email=$1", [email]))
        .rows.length > 0 ||
      (await pool.query("SELECT 1 FROM lecturers WHERE email=$1", [email]))
        .rows.length > 0 ||
      (await pool.query("SELECT 1 FROM students WHERE email=$1", [email]))
        .rows.length > 0;

    if (existing) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const hashed = await bcrypt.hash(password, 10);

    // Insert new student
    const result = await pool.query(
      "INSERT INTO students (student_code, fullname, email, password, created_at) VALUES (concat('STU', lpad(nextval('student_seq')::text, 6, '0')), $1, $2, $3, NOW()) RETURNING id, student_code, fullname, email",
      [fullname, email, hashed]
    );

    res.json({
      message: "Registration successful",
      user: result.rows[0],
    });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ error: "Registration failed" });
  }
});

/* ======================
   ✅ LOGIN (ID OR EMAIL)
   ====================== */
app.post("/api/login", async (req, res) => {
  try {
    const { identifier, password } = req.body;

    if (!identifier || !password) {
      return res
        .status(400)
        .json({ error: "Identifier and password are required" });
    }

    let result = await pool.query(
      "SELECT id, admin_code AS userid, fullname, email, password, 'admin' AS role FROM admins WHERE admin_code = $1 OR email = $1",
      [identifier]
    );

    if (result.rows.length === 0) {
      result = await pool.query(
        "SELECT id, lecturer_code AS userid, fullname, email, password, 'lecturer' AS role FROM lecturers WHERE lecturer_code = $1 OR email = $1",
        [identifier]
      );
    }

    if (result.rows.length === 0) {
      result = await pool.query(
        "SELECT id, student_code AS userid, fullname, email, password, 'student' AS role FROM students WHERE student_code = $1 OR email = $1",
        [identifier]
      );
    }

    if (result.rows.length === 0) {
      return res.status(400).json({ error: "Invalid ID/Email or password" });
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(400).json({ error: "Invalid ID/Email or password" });
    }

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        code: user.userid,
        fullname: user.fullname,
        email: user.email,
        role: user.role,
      },
      redirect:
        user.role === "admin"
          ? "../Frontend/HTML/Users/admin.html"
          : user.role === "lecturer"
          ? "../Frontend/HTML/Users/lecturer.html"
          : "../Frontend/HTML/Users/Student.html",
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error during login" });
  }
});

/* ======================
   ✅ CHANGE PASSWORD (SELF)
   ====================== */
app.post("/api/change-password", async (req, res) => {
  try {
    const { identifier, currentPassword, newPassword } = req.body;

    if (!identifier || !currentPassword || !newPassword) {
      return res
        .status(400)
        .json({ error: "Identifier, current password and new password are required" });
    }

    // Check all roles
    let result = await pool.query(
      "SELECT id, password, 'admin' AS role FROM admins WHERE admin_code = $1 OR email = $1",
      [identifier]
    );
    if (result.rows.length === 0) {
      result = await pool.query(
        "SELECT id, password, 'lecturer' AS role FROM lecturers WHERE lecturer_code = $1 OR email = $1",
        [identifier]
      );
    }
    if (result.rows.length === 0) {
      result = await pool.query(
        "SELECT id, password, 'student' AS role FROM students WHERE student_code = $1 OR email = $1",
        [identifier]
      );
    }

    if (result.rows.length === 0) {
      return res.status(400).json({ error: "User not found" });
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(currentPassword, user.password);
    if (!validPassword) {
      return res.status(400).json({ error: "Current password is incorrect" });
    }

    const hashed = await bcrypt.hash(newPassword, 10);

    if (user.role === "admin") {
      await pool.query("UPDATE admins SET password=$1 WHERE id=$2", [hashed, user.id]);
    } else if (user.role === "lecturer") {
      await pool.query("UPDATE lecturers SET password=$1 WHERE id=$2", [hashed, user.id]);
    } else {
      await pool.query("UPDATE students SET password=$1 WHERE id=$2", [hashed, user.id]);
    }

    res.json({ message: "Password updated successfully" });
  } catch (err) {
    console.error("Change password error:", err);
    res.status(500).json({ error: "Failed to change password" });
  }
});

/* ======================
   ✅ RESET PASSWORD (ADMIN / SUPPORT)
   ====================== */
app.post("/api/reset-password", async (req, res) => {
  try {
    const { identifier, newPassword } = req.body;

    if (!identifier || !newPassword) {
      return res
        .status(400)
        .json({ error: "Identifier and new password are required" });
    }

    const hashed = await bcrypt.hash(newPassword, 10);

    // Update whichever role matches
    let result = await pool.query(
      "UPDATE admins SET password=$1 WHERE admin_code=$2 OR email=$2 RETURNING id",
      [hashed, identifier]
    );

    if (result.rows.length === 0) {
      result = await pool.query(
        "UPDATE lecturers SET password=$1 WHERE lecturer_code=$2 OR email=$2 RETURNING id",
        [hashed, identifier]
      );
    }

    if (result.rows.length === 0) {
      result = await pool.query(
        "UPDATE students SET password=$1 WHERE student_code=$2 OR email=$2 RETURNING id",
        [hashed, identifier]
      );
    }

    if (result.rows.length === 0) {
      return res.status(400).json({ error: "User not found" });
    }

    res.json({ message: "Password reset successfully" });
  } catch (err) {
    console.error("Reset password error:", err);
    res.status(500).json({ error: "Failed to reset password" });
  }
});

/* ======================
   ✅ START SERVER
   ====================== */
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
