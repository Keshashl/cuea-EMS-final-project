// backend/routes/auth.js
const express = require("express");
const router = express.Router();
const pool = require("../database/pool");


// Register user
router.post("/register", async (req, res) => {
  const { role, fullname, email, password } = req.body;

  try {
    let table, codeColumn;

    if (role === "admin") {
      table = "admins";
      codeColumn = "admin_code";
    } else if (role === "lecturer") {
      table = "lecturers";
      codeColumn = "lecturer_code";
    } else if (role === "student") {
      table = "students";
      codeColumn = "student_code";
    } else {
      return res.status(400).json({ error: "Invalid role" });
    }

    const result = await pool.query(
      `INSERT INTO ${table} (fullname, email, password)
       VALUES ($1, $2, $3)
       RETURNING id, ${codeColumn}, fullname, email, created_at`,
      [fullname, email, password]
    );

    res.status(201).json({
      message: "Registration successful",
      user: result.rows[0],
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Registration failed" });
  }
});

module.exports = router;

// backend/routes/auth.js (continue in same file)

// Login user
router.post("/login", async (req, res) => {
  const { role, email, password } = req.body;

  try {
    let table, codeColumn;

    if (role === "admin") {
      table = "admins";
      codeColumn = "admin_code";
    } else if (role === "lecturer") {
      table = "lecturers";
      codeColumn = "lecturer_code";
    } else if (role === "student") {
      table = "students";
      codeColumn = "student_code";
    } else {
      return res.status(400).json({ error: "Invalid role" });
    }

    const result = await pool.query(
      `SELECT id, ${codeColumn}, fullname, email, password 
       FROM ${table} 
       WHERE email = $1`,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: "User not found" });
    }

    const user = result.rows[0];

    // ⚠️ For now, we compare plain passwords
    // Later we’ll switch to bcrypt
    if (user.password !== password) {
      return res.status(401).json({ error: "Invalid password" });
    }

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        code: user[codeColumn],
        fullname: user.fullname,
        email: user.email,
        role,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});
