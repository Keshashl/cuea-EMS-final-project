const express = require("express");
const pool = require("../database/pool");
const router = express.Router();

/* ==========================
   ➕ SUBMIT AN EXAM (One-time only)
   ========================== */
router.post("/submit", async (req, res) => {
  const client = await pool.connect();
  try {
    const { exam_id, student_id, answers } = req.body;

    if (!exam_id || !student_id || !answers || !Array.isArray(answers)) {
      return res.status(400).json({ error: "exam_id, student_id, and answers[] are required" });
    }

    await client.query("BEGIN");

    // 🔹 Insert submission (fail if already exists)
    const submissionResult = await client.query(
      `INSERT INTO submissions (exam_id, student_id, submitted_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (exam_id, student_id) DO NOTHING
       RETURNING id`,
      [exam_id, student_id]
    );

    if (submissionResult.rows.length === 0) {
      // Student already submitted
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "You have already submitted this exam." });
    }

    const submissionId = submissionResult.rows[0].id;

    // 🔹 Insert answers
    for (const ans of answers) {
      await client.query(
        `INSERT INTO answers (submission_id, question_id, selected_option, answer_text)
         VALUES ($1, $2, $3, $4)`,
        [submissionId, ans.question_id, ans.selected_option || null, ans.answer_text || null]
      );
    }

    await client.query("COMMIT");
    res.json({ message: "✅ Exam submitted successfully", submission_id: submissionId });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Error submitting exam:", err);
    res.status(500).json({ error: "Failed to submit exam" });
  } finally {
    client.release();
  }
});

/* ==========================
   📊 GET STUDENT RESULTS WITH SCORE (🚨 must be before /:exam_id/:student_id)
   ========================== */
router.get("/results/:student_id", async (req, res) => {
  try {
    const studentId = parseInt(req.params.student_id, 10);

    const result = await pool.query(
      `SELECT e.title, e.exam_type, s.submitted_at,
              COUNT(q.id) FILTER (WHERE q.correct_option = a.selected_option) AS score,
              COUNT(q.id) AS total
       FROM submissions s
       JOIN exams e ON s.exam_id = e.id
       JOIN answers a ON s.id = a.submission_id
       JOIN questions q ON a.question_id = q.id
       WHERE s.student_id = $1
       GROUP BY e.title, e.exam_type, s.submitted_at
       ORDER BY s.submitted_at DESC`,
      [studentId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching results:", err);
    res.status(500).json({ error: "Failed to fetch results" });
  }
});

/* ==========================
   📥 GET ALL SUBMISSIONS FOR A STUDENT
   ========================== */
router.get("/student/:student_id", async (req, res) => {
  try {
    const { student_id } = req.params;

    const result = await pool.query(
      `SELECT exam_id, submitted_at 
       FROM submissions 
       WHERE student_id = $1`,
      [student_id]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching student submissions:", err);
    res.status(500).json({ error: "Failed to fetch student submissions" });
  }
});

/* ==========================
   📥 GET ALL SUBMISSIONS FOR AN EXAM (Lecturer/Admin)
   ========================== */
router.get("/exam/:exam_id", async (req, res) => {
  try {
    const { exam_id } = req.params;

    const result = await pool.query(
      `SELECT s.id AS submission_id, s.student_id, s.submitted_at,
              a.question_id, a.selected_option, a.answer_text
       FROM submissions s
       LEFT JOIN answers a ON s.id = a.submission_id
       WHERE s.exam_id = $1
       ORDER BY s.student_id`,
      [exam_id]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching submissions:", err);
    res.status(500).json({ error: "Failed to fetch submissions" });
  }
});

/* ==========================
   🔍 CHECK IF STUDENT ALREADY SUBMITTED (specific exam)
   ========================== */
router.get("/check/:exam_id/:student_id", async (req, res) => {
  try {
    const { exam_id, student_id } = req.params;

    const result = await pool.query(
      `SELECT 1 FROM submissions WHERE exam_id = $1 AND student_id = $2`,
      [exam_id, student_id]
    );

    if (result.rows.length > 0) {
      return res.json({ submitted: true });
    }

    res.json({ submitted: false });
  } catch (err) {
    console.error("❌ Error checking submission:", err);
    res.status(500).json({ error: "Failed to check submission" });
  }
});

/* ==========================
   📥 GET A STUDENT'S SUBMISSION (specific exam)
   ========================== */
router.get("/:exam_id/:student_id", async (req, res) => {
  try {
    const { exam_id, student_id } = req.params;

    const result = await pool.query(
      `SELECT s.id AS submission_id, s.exam_id, s.student_id, s.submitted_at,
              a.question_id, a.selected_option, a.answer_text
       FROM submissions s
       LEFT JOIN answers a ON s.id = a.submission_id
       WHERE s.exam_id = $1 AND s.student_id = $2`,
      [exam_id, student_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Submission not found" });
    }

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching submission:", err);
    res.status(500).json({ error: "Failed to fetch submission" });
  }
});

module.exports = router;
