// backend/routes/lecturers.js
const express = require("express");
const bcrypt = require("bcrypt");
const pool = require("../database/pool"); // Ensure this is your DB connection
const router = express.Router();

/* =====================
   📋 Get all lecturers
===================== */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, lecturer_code, fullname, email FROM lecturers ORDER BY id ASC"
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching lecturers:", err);
    res.status(500).json({ error: "Failed to fetch lecturers" });
  }
});

/* =====================
   📝 Register a lecturer
===================== */
router.post("/register", async (req, res) => {
  try {
    const { fullname, email, password } = req.body;
    if (!fullname || !email || !password) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate lecturer code (e.g., LEC000001)
    const codeResult = await pool.query("SELECT COUNT(*) FROM lecturers");
    const count = parseInt(codeResult.rows[0].count) + 1;
    const lecturer_code = "LEC" + String(count).padStart(6, "0");

    const insert = await pool.query(
      `INSERT INTO lecturers (lecturer_code, fullname, email, password) 
       VALUES ($1, $2, $3, $4) 
       RETURNING id, lecturer_code, fullname, email`,
      [lecturer_code, fullname, email, hashedPassword]
    );

    res.json(insert.rows[0]);
  } catch (err) {
    console.error("Error registering lecturer:", err);
    res.status(500).json({ error: "Failed to register lecturer" });
  }
});

/* =====================
   🗑 Delete a lecturer
===================== */
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query("DELETE FROM lecturers WHERE id = $1 RETURNING id", [id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Lecturer not found" });
    }

    res.json({ message: "Lecturer deleted successfully" });
  } catch (err) {
    console.error("Error deleting lecturer:", err);
    res.status(500).json({ error: "Failed to delete lecturer" });
  }
});

module.exports = router;
