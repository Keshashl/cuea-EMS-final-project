const express = require("express");
const router = express.Router();
const pool = require("../database/pool"); // your pg pool

// ✅ Get all events (students & admins can view)
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, description, event_date FROM events ORDER BY event_date"
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch events" });
  }
});

// ✅ Add event (Admins only)
router.post("/add", async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Not allowed" });
    }

    const { description, event_date } = req.body;
    await pool.query(
      "INSERT INTO events (description, event_date, created_by) VALUES ($1, $2, $3)",
      [description, event_date, req.user.id]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to add event" });
  }
});

module.exports = router;
