const express = require("express");
const router = express.Router();
const pool = require("../database/pool");

/* =========================
   ➕ ADD QUESTION TO AN EXAM
   ========================= */
router.post("/create", async (req, res) => {
  try {
    const { exam_id, question_text, option_a, option_b, option_c, option_d, correct_option } = req.body;

    if (!exam_id || !question_text || !correct_option) {
      return res.status(400).json({ 
        error: "exam_id, question_text, and correct_option are required" 
      });
    }

    const result = await pool.query(
      `INSERT INTO questions 
        (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING *`,
      [exam_id, question_text, option_a, option_b, option_c, option_d, correct_option]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error creating question:", err);
    res.status(500).json({ error: "Failed to create question" });
  }
});

/* =========================
   📜 GET ALL QUESTIONS FOR AN EXAM
   ========================= */
router.get("/exam/:exam_id", async (req, res) => {
  try {
    const { exam_id } = req.params;
    const result = await pool.query(
      `SELECT * FROM questions WHERE exam_id=$1 ORDER BY id ASC`,
      [exam_id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching questions:", err);
    res.status(500).json({ error: "Failed to fetch questions" });
  }
});

/* =========================
   🔍 GET SINGLE QUESTION
   ========================= */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`SELECT * FROM questions WHERE id=$1`, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Question not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error fetching question:", err);
    res.status(500).json({ error: "Failed to fetch question" });
  }
});

/* =========================
   ✏️ UPDATE QUESTION
   ========================= */
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { question_text, option_a, option_b, option_c, option_d, correct_option } = req.body;

    const result = await pool.query(
      `UPDATE questions 
       SET question_text=$1, option_a=$2, option_b=$3, option_c=$4, option_d=$5, correct_option=$6
       WHERE id=$7 RETURNING *`,
      [question_text, option_a, option_b, option_c, option_d, correct_option, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Question not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error updating question:", err);
    res.status(500).json({ error: "Failed to update question" });
  }
});

/* =========================
   ❌ DELETE QUESTION
   ========================= */
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`DELETE FROM questions WHERE id=$1 RETURNING *`, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Question not found" });
    }

    res.json({ message: "Question deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting question:", err);
    res.status(500).json({ error: "Failed to delete question" });
  }
});

module.exports = router;
