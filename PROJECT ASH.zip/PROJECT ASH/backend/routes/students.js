// backend/routes/students.js
const express = require("express");
const router = express.Router();
const pool = require("../database/pool");

/* =====================
   📚 Get all students
===================== */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, student_code, fullname, email FROM students ORDER BY fullname"
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching students:", err);
    res.status(500).json({ error: "Failed to fetch students" });
  }
});

/* =====================
   📊 Get results for one student
===================== */
router.get("/:id/results", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `SELECT s.id, e.title AS exam_title, s.submitted_at
       FROM submissions s
       JOIN exams e ON s.exam_id = e.id
       WHERE s.student_id = $1
       ORDER BY s.submitted_at DESC`,
      [id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching results:", err);
    res.status(500).json({ error: "Failed to fetch results" });
  }
});

/* =====================
   🗑 Delete a student
===================== */
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query("DELETE FROM students WHERE id = $1 RETURNING id", [id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Student not found" });
    }

    res.json({ message: "Student deleted successfully" });
  } catch (err) {
    console.error("Error deleting student:", err);
    res.status(500).json({ error: "Failed to delete student" });
  }
});

module.exports = router;
