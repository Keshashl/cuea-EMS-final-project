// backend/routes/stats.js
const express = require("express");
const router = express.Router();
const pool = require("../database/pool");
console.log("📊 Stats route loaded");


// 📊 Overview Stats Endpoint
router.get("/overview", async (req, res) => {
  try {
    // Count students
    const students = await pool.query("SELECT COUNT(*) FROM students");

    // Count lecturers
    const lecturers = await pool.query("SELECT COUNT(*) FROM lecturers");

    // Count exams (if no exams yet, returns 0)
    const exams = await pool.query("SELECT COUNT(*) FROM exams");

    // Send JSON response
    res.json({
      students: parseInt(students.rows[0].count, 10),
      lecturers: parseInt(lecturers.rows[0].count, 10),
      exams: parseInt(exams.rows[0].count, 10),
    });
  } catch (err) {
    console.error("❌ Stats fetch error:", err);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

module.exports = router;
