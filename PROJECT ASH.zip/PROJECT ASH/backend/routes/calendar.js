const express = require("express");
const pool = require("../database/pool"); // Assuming you have a pool of DB connections

const router = express.Router();

// --------------------------
// GET EVENTS
// --------------------------
router.get("/events", async (req, res) => {
  try {
    const { role, code } = req.query; // Role (admin, student, lecturer), and user code (student_code, lecturer_code, admin_code)

    if (role === "admin") {
      // Admin can see all events
      const result = await pool.query("SELECT * FROM calendar_events WHERE is_public = true OR is_public = false");
      return res.json(result.rows);
    } else {
      // Students and Lecturers can only see their private events (those created by them)
      const result = await pool.query(
        "SELECT * FROM calendar_events WHERE created_by = $1 AND (is_public = false OR is_public = true)",
        [code]
      );
      return res.json(result.rows);
    }
  } catch (err) {
    console.error("Error fetching events:", err);
    return res.status(500).json({ error: "Error fetching events" });
  }
});

// --------------------------
// CREATE EVENT (Admin - Public, Lecturer/Student - Private)
// --------------------------
router.post("/events", async (req, res) => {
  try {
    const { title, start_time, created_by, role } = req.body;

    if (!title || !start_time || !created_by) {
      return res.status(400).json({ error: "Title, start time, and created_by are required" });
    }

    // Admin events should be public (is_public = true), others should be private (is_public = false)
    const isPublic = role === "admin" ? true : false;

    // Insert the event into the database
    const result = await pool.query(
      "INSERT INTO calendar_events (title, start_time, created_by, is_public) VALUES ($1, $2, $3, $4) RETURNING *",
      [title, start_time, created_by, isPublic]
    );

    res.status(201).json({
      message: "Event created successfully",
      event: result.rows[0],
    });
  } catch (err) {
    console.error("Error creating event:", err);
    return res.status(500).json({ error: "Error creating event" });
  }
});

module.exports = router;
