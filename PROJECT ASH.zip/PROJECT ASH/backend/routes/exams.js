const express = require("express");
const router = express.Router();
const pool = require("../database/pool");

/* =========================
   ➕ CREATE AN EXAM
   ========================= */
router.post("/create", async (req, res) => {
  try {
    const { course_id, exam_date, exam_type, title, description, duration_minutes, status } = req.body;

    if (!course_id || !exam_date || !exam_type || !title) {
      return res.status(400).json({ 
        error: "course_id, exam_date, exam_type, and title are required" 
      });
    }

    const result = await pool.query(
      `INSERT INTO exams (course_id, exam_date, exam_type, title, description, duration_minutes, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING *`,
      [
        course_id,
        exam_date,
        exam_type,
        title,
        description || null,
        duration_minutes || 60,
        status || "draft"
      ]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error creating exam:", err);
    res.status(500).json({ error: "Failed to create exam" });
  }
});

/* =========================
   📜 GET ALL EXAMS
   ========================= */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM exams ORDER BY exam_date DESC`);
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching exams:", err);
    res.status(500).json({ error: "Failed to fetch exams" });
  }
});

router.get("/all", async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM exams ORDER BY exam_date DESC`);
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Error fetching exams:", err);
    res.status(500).json({ error: "Failed to fetch exams" });
  }
});

/* =========================
   🔍 GET ONE EXAM BY ID (with questions)
   ========================= */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Fetch exam metadata
    const examResult = await pool.query(`SELECT * FROM exams WHERE id = $1`, [id]);
    if (examResult.rows.length === 0)
      return res.status(404).json({ error: "Exam not found" });

    const exam = examResult.rows[0];

    // Fetch exam questions
    const questionsResult = await pool.query(
      `SELECT id, question_text, option_a, option_b, option_c, option_d, correct_option 
       FROM questions WHERE exam_id = $1`,
      [id]
    );

    exam.questions = questionsResult.rows.map(q => ({
      id: q.id,
      question_text: q.question_text,
      options: [q.option_a, q.option_b, q.option_c, q.option_d]
    }));

    res.json(exam);
  } catch (err) {
    console.error("❌ Error fetching exam:", err);
    res.status(500).json({ error: "Failed to fetch exam" });
  }
});

/* =========================
   📝 SUBMIT EXAM
   ========================= */
router.post("/:id/submit", async (req, res) => {
  try {
    const { id } = req.params;
    const { answers } = req.body; // { questionId: selectedOption }

    // Fetch correct answers
    const correctResult = await pool.query(
      `SELECT id, correct_option FROM questions WHERE exam_id=$1`,
      [id]
    );

    let score = 0;
    correctResult.rows.forEach(q => {
      if (answers[q.id] && answers[q.id] === q.correct_option) score++;
    });

    res.json({ score, total: correctResult.rows.length });
  } catch (err) {
    console.error("❌ Error submitting exam:", err);
    res.status(500).json({ error: "Failed to submit exam" });
  }
});

/* =========================
   ✏️ UPDATE EXAM STATUS
   ========================= */
router.put("/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const result = await pool.query(
      `UPDATE exams SET status=$1 WHERE id=$2 RETURNING *`,
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Exam not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Error updating exam status:", err);
    res.status(500).json({ error: "Failed to update exam status" });
  }
});

/* =========================
   ❌ DELETE AN EXAM
   ========================= */
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`DELETE FROM exams WHERE id=$1 RETURNING *`, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Exam not found" });
    }

    res.json({ message: "Exam deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting exam:", err);
    res.status(500).json({ error: "Failed to delete exam" });
  }
});

module.exports = router;
