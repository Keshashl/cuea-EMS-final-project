// test-app.js
require("dotenv").config();
const express = require("express");
const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

// ✅ Minimal Stats route
app.get("/api/stats/overview", (req, res) => {
  console.log("➡️ /api/stats/overview called");
  res.json({
    students: 10,
    lecturers: 5,
    exams: 3,
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Test server running on http://localhost:${PORT}`);
});
