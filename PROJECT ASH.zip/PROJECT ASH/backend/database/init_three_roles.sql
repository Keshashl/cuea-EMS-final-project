-- init_three_roles.sql
-- Drops and recreates a Full EMS schema using 3 separate role tables:
-- admins, lecturers, students (each with auto-generated ADM/LEC/STU codes)
-- plus courses, exams, results. Seeded with one of each.

-- DROP (safe for re-runs)
DROP TABLE IF EXISTS results CASCADE;
DROP TABLE IF EXISTS exams CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP TABLE IF EXISTS students CASCADE;
DROP TABLE IF EXISTS lecturers CASCADE;
DROP TABLE IF EXISTS admins CASCADE;

DROP TABLE IF EXISTS sessions CASCADE;
DROP TABLE IF EXISTS questions CASCADE;
DROP TABLE IF EXISTS users CASCADE;

DROP SEQUENCE IF EXISTS admin_seq CASCADE;
DROP SEQUENCE IF EXISTS lecturer_seq CASCADE;
DROP SEQUENCE IF EXISTS student_seq CASCADE;

-- Sequences for code counters
CREATE SEQUENCE admin_seq START 1;
CREATE SEQUENCE lecturer_seq START 1;
CREATE SEQUENCE student_seq START 1;

-- Admins
CREATE TABLE admins (
  id          SERIAL PRIMARY KEY,
  admin_code  VARCHAR(20) UNIQUE NOT NULL,
  fullname    VARCHAR(100) NOT NULL,
  email       VARCHAR(255) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lecturers
CREATE TABLE lecturers (
  id            SERIAL PRIMARY KEY,
  lecturer_code VARCHAR(20) UNIQUE NOT NULL,
  fullname      VARCHAR(100) NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password      VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students
CREATE TABLE students (
  id           SERIAL PRIMARY KEY,
  student_code VARCHAR(20) UNIQUE NOT NULL,
  fullname     VARCHAR(100) NOT NULL,
  email        VARCHAR(255) UNIQUE NOT NULL,
  password     VARCHAR(255) NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Courses
CREATE TABLE courses (
  id           SERIAL PRIMARY KEY,
  code         VARCHAR(20) UNIQUE NOT NULL,
  name         VARCHAR(120) NOT NULL,
  lecturer_id  INT REFERENCES lecturers(id) ON DELETE SET NULL
);

-- Exams
CREATE TABLE exams (
  id         SERIAL PRIMARY KEY,
  course_id  INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  exam_date  DATE NOT NULL,
  exam_type  VARCHAR(30) NOT NULL
);

-- Results
CREATE TABLE results (
  id         SERIAL PRIMARY KEY,
  exam_id    INT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  student_id INT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  score      NUMERIC(5,2) NOT NULL,
  CONSTRAINT uq_exam_student UNIQUE (exam_id, student_id)
);

-- Trigger functions for auto-generating role codes
CREATE OR REPLACE FUNCTION generate_admin_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.admin_code IS NULL OR NEW.admin_code = '' THEN
    NEW.admin_code := 'ADM' || TO_CHAR(nextval('admin_seq'), 'FM000000');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION generate_lecturer_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.lecturer_code IS NULL OR NEW.lecturer_code = '' THEN
    NEW.lecturer_code := 'LEC' || TO_CHAR(nextval('lecturer_seq'), 'FM000000');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION generate_student_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.student_code IS NULL OR NEW.student_code = '' THEN
    NEW.student_code := 'STU' || TO_CHAR(nextval('student_seq'), 'FM000000');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers to call the functions
CREATE TRIGGER trg_admin_code BEFORE INSERT ON admins FOR EACH ROW EXECUTE FUNCTION generate_admin_code();
CREATE TRIGGER trg_lecturer_code BEFORE INSERT ON lecturers FOR EACH ROW EXECUTE FUNCTION generate_lecturer_code();
CREATE TRIGGER trg_student_code BEFORE INSERT ON students FOR EACH ROW EXECUTE FUNCTION generate_student_code();

-- Seed sample accounts (passwords are plaintext for seed; replace with hashed in production)
INSERT INTO admins (fullname, email, password) VALUES ('System Admin','admin@example.com','admin123');
INSERT INTO lecturers (fullname, email, password) VALUES ('Jane Lecturer','jane.lect@example.com','lect123');
INSERT INTO students (fullname, email, password) VALUES ('John Student','john.stud@example.com','stud123');

-- Sample course, exam, result
INSERT INTO courses (code, name, lecturer_id)
VALUES ('CMT101','Computer Networks',(SELECT id FROM lecturers LIMIT 1));

INSERT INTO exams (course_id, exam_date, exam_type)
VALUES ((SELECT id FROM courses WHERE code='CMT101'), CURRENT_DATE, 'CAT');

INSERT INTO results (exam_id, student_id, score)
VALUES (
  (SELECT id FROM exams ORDER BY id DESC LIMIT 1),
  (SELECT id FROM students LIMIT 1),
  78.50
);
