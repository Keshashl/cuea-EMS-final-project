// backend/database/db.js
const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "ems",
  password: "your_password", // <-- replace with your postgres password
  port: 5432,
});

module.exports = pool;
